# GitGuardian-scanner
GitGuardian scan workflow for secrets finding.
